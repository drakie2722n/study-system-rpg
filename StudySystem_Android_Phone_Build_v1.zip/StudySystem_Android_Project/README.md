# Study System — Android project (v1.0)

An offline-first Android WebView app for turning study tasks into RPG-style quests.

## Included features
- Shadow Blue / Purple Shadow theme switch
- XP, levels, E-to-S ranks and progress stats
- Daily quest board and custom quests
- PYQ Dungeon quest logger for JEE Main and CBSE Boards
- Subject, year/session and chapter logging
- Accuracy and attempted-question tracking
- Focus timer (25 / 45 / 60 minutes)
- Local device storage (no account or internet required)

## Build an APK with Android Studio
1. Install Android Studio and its Android SDK (API 35 or a compatible SDK).
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `StudySystem_Android_Project` folder.
4. Allow Gradle sync and install any SDK components Android Studio requests.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer it to your Android phone and install it. If Android asks, allow installation from the file manager you used.

## Notes
- The project is source code, not a precompiled APK. This environment did not have Android SDK/Gradle, so the APK could not be built or device-tested here.
- PYQ Dungeon currently tracks your practice sessions and rewards XP. It does not bundle copyrighted official question-paper text. Add questions from official/authorized PYQ sources when practising.
- Progress is stored locally in the app's WebView storage. Clearing app data will clear progress.


## Build using only an Android phone (GitHub Actions)
1. Sign in to GitHub in your phone browser and create a new repository.
2. Upload the contents of this project ZIP to the repository (make sure hidden `.github` folder is included; if the mobile upload screen hides it, use GitHub's web editor to create `.github/workflows/android-apk.yml` from the included workflow file).
3. Open the repository's **Actions** tab and select **Build Study System APK**.
4. Tap **Run workflow** if it has not started automatically.
5. When the run completes successfully, open it and download the `Study-System-debug-APK` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your phone.
